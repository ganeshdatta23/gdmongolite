"""gdmongolite: lightweight, auto-maintained all-in-one MongoDB toolkit by Ganeshdatta"""
__version__ = "0.1.0"

from .core import DB, Schema, Email, Positive
