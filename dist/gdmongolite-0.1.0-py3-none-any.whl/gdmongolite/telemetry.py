# Telemetry hooks for gdmongolite
